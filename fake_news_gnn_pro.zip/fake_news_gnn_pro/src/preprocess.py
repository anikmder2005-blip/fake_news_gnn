"""
Step 1 & 2: Load dataset and clean text.

Pipeline:
    Raw article -> Lowercase -> Remove URLs/punctuation/digits ->
    Remove stopwords -> Clean article
"""
import os
BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
import re
import pandas as pd
from sklearn.feature_extraction.text import ENGLISH_STOP_WORDS

STOPWORDS = ENGLISH_STOP_WORDS

URL_RE = re.compile(r"https?://\S+|www\.\S+")
NON_ALPHA_RE = re.compile(r"[^a-zA-Z\s]")
MULTI_SPACE_RE = re.compile(r"\s+")


def clean_text(text: str) -> str:
    """Lowercase, strip urls/punctuation/numbers, drop stopwords."""
    if not isinstance(text, str):
        return ""
    text = text.lower()
    text = URL_RE.sub(" ", text)
    text = NON_ALPHA_RE.sub(" ", text)
    tokens = [t for t in text.split() if t not in STOPWORDS and len(t) > 2]
    text = " ".join(tokens)
    text = MULTI_SPACE_RE.sub(" ", text).strip()
    return text


def load_and_clean(csv_path: str) -> pd.DataFrame:
    """Load the raw dataset and produce a cleaned dataframe.

    Expected columns: id, title, text, label (FAKE/REAL)
    """
    df = pd.read_csv(csv_path)
    df = df.dropna(subset=["text", "label"]).reset_index(drop=True)

    # Combine title + body; title often carries strong signal for fake news
    df["title"] = df["title"].fillna("")
    df["full_text"] = (df["title"] + ". " + df["text"]).astype(str)

    print("Cleaning text (this may take a little while for ~6k articles)...")
    df["clean_text"] = df["full_text"].apply(clean_text)

    # Binary label: 1 = FAKE, 0 = REAL
    df["y"] = (df["label"].str.upper() == "FAKE").astype(int)

    # Drop rows that became empty after cleaning
    df = df[df["clean_text"].str.len() > 0].reset_index(drop=True)
    return df


if __name__ == "__main__":
    df = load_and_clean(BASE + "/data/fake_or_real_news.csv")
    print(df[["title", "clean_text", "label", "y"]].head())
    print("Shape after cleaning:", df.shape)
    df.to_csv(BASE + "/data/cleaned_news.csv", index=False)
    print("Saved cleaned dataset to data/cleaned_news.csv")
