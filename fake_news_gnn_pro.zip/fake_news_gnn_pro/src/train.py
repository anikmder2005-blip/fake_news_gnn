"""
Step 6 & 7: Train the GCN, train baseline models, evaluate everything,
and save all results (metrics, confusion matrix, plots, model checkpoint).
"""
import os
BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
import json
import pickle
import numpy as np
import scipy.sparse as sp
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

import torch
import torch.nn.functional as F
from torch_geometric.data import Data
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (accuracy_score, precision_score, recall_score,
                              f1_score, confusion_matrix)

from model import FakeNewsGCN

RANDOM_STATE = 42
DATA_DIR = BASE + "/data"
RESULTS_DIR = BASE + "/results"
MODELS_DIR = BASE + "/models"

torch.manual_seed(RANDOM_STATE)
np.random.seed(RANDOM_STATE)


def load_data():
    X = sp.load_npz(f"{DATA_DIR}/node_features.npz")
    edge_index = np.load(f"{DATA_DIR}/edge_index.npy")
    y = np.load(f"{DATA_DIR}/labels.npy")
    return X, edge_index, y


def make_masks(n, y, train_size=0.6, val_size=0.2, seed=RANDOM_STATE):
    idx = np.arange(n)
    idx_train, idx_temp = train_test_split(
        idx, train_size=train_size, stratify=y, random_state=seed)
    rel_val = val_size / (1 - train_size)
    idx_val, idx_test = train_test_split(
        idx_temp, train_size=rel_val, stratify=y[idx_temp], random_state=seed)

    train_mask = np.zeros(n, dtype=bool)
    val_mask = np.zeros(n, dtype=bool)
    test_mask = np.zeros(n, dtype=bool)
    train_mask[idx_train] = True
    val_mask[idx_val] = True
    test_mask[idx_test] = True
    return train_mask, val_mask, test_mask


def evaluate(y_true, y_pred):
    return {
        "accuracy": float(accuracy_score(y_true, y_pred)),
        "precision": float(precision_score(y_true, y_pred, zero_division=0)),
        "recall": float(recall_score(y_true, y_pred, zero_division=0)),
        "f1": float(f1_score(y_true, y_pred, zero_division=0)),
    }


def plot_confusion(cm, title, path):
    fig, ax = plt.subplots(figsize=(4, 4))
    im = ax.imshow(cm, cmap="Blues")
    ax.set_xticks([0, 1]); ax.set_xticklabels(["REAL", "FAKE"])
    ax.set_yticks([0, 1]); ax.set_yticklabels(["REAL", "FAKE"])
    ax.set_xlabel("Predicted"); ax.set_ylabel("Actual")
    ax.set_title(title)
    for i in range(2):
        for j in range(2):
            ax.text(j, i, str(cm[i, j]), ha="center", va="center",
                     color="white" if cm[i, j] > cm.max() / 2 else "black")
    fig.colorbar(im, fraction=0.046, pad=0.04)
    fig.tight_layout()
    fig.savefig(path, dpi=150)
    plt.close(fig)


def train_baselines(X, y, train_mask, test_mask):
    results = {}
    X_train, X_test = X[train_mask], X[test_mask]
    y_train, y_test = y[train_mask], y[test_mask]

    lr = LogisticRegression(max_iter=1000, random_state=RANDOM_STATE)
    lr.fit(X_train, y_train)
    pred = lr.predict(X_test)
    results["Logistic Regression"] = evaluate(y_test, pred)
    results["Logistic Regression"]["confusion_matrix"] = confusion_matrix(y_test, pred).tolist()

    rf = RandomForestClassifier(n_estimators=200, random_state=RANDOM_STATE, n_jobs=-1)
    rf.fit(X_train, y_train)
    pred = rf.predict(X_test)
    results["Random Forest"] = evaluate(y_test, pred)
    results["Random Forest"]["confusion_matrix"] = confusion_matrix(y_test, pred).tolist()

    return results


def train_gcn(X, edge_index, y, train_mask, val_mask, test_mask,
              hidden=64, epochs=100, lr=0.01, weight_decay=5e-4, dropout=0.5,
              svd_dim=128):
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    if svd_dim is not None and svd_dim < X.shape[1]:
        from sklearn.decomposition import TruncatedSVD
        svd = TruncatedSVD(n_components=svd_dim, random_state=RANDOM_STATE)
        X_dense = svd.fit_transform(X)
        with open(f"{MODELS_DIR}/svd.pkl", "wb") as f:
            pickle.dump(svd, f)
    else:
        X_dense = X.toarray()

    x = torch.tensor(X_dense, dtype=torch.float)
    ei = torch.tensor(edge_index, dtype=torch.long)
    # make undirected (both directions) for message passing
    ei = torch.cat([ei, ei.flip(0)], dim=1)
    y_t = torch.tensor(y, dtype=torch.long)

    data = Data(x=x, edge_index=ei, y=y_t)
    data.train_mask = torch.tensor(train_mask)
    data.val_mask = torch.tensor(val_mask)
    data.test_mask = torch.tensor(test_mask)
    data = data.to(device)

    model = FakeNewsGCN(in_channels=x.shape[1], hidden_channels=hidden,
                         
                         num_classes=2, dropout=dropout).to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=lr, weight_decay=weight_decay)

    history = {"epoch": [], "train_loss": [], "val_acc": []}
    best_val_acc = 0.0
    best_state = None

    for epoch in range(1, epochs + 1):
        model.train()
        optimizer.zero_grad()
        out = model(data.x, data.edge_index)
        loss = F.cross_entropy(out[data.train_mask], data.y[data.train_mask])
        loss.backward()
        optimizer.step()

        model.eval()
        with torch.no_grad():
            out = model(data.x, data.edge_index)
            pred = out.argmax(dim=1)
            val_acc = (pred[data.val_mask] == data.y[data.val_mask]).float().mean().item()

        history["epoch"].append(epoch)
        history["train_loss"].append(loss.item())
        history["val_acc"].append(val_acc)

        if val_acc > best_val_acc:
            best_val_acc = val_acc
            best_state = {k: v.clone() for k, v in model.state_dict().items()}

        if epoch % 10 == 0 or epoch == 1:
            print(f"Epoch {epoch:3d} | loss={loss.item():.4f} | val_acc={val_acc:.4f}")

    model.load_state_dict(best_state)
    model.eval()
    with torch.no_grad():
        out = model(data.x, data.edge_index)
        pred = out.argmax(dim=1)
        test_pred = pred[data.test_mask].cpu().numpy()
        test_true = data.y[data.test_mask].cpu().numpy()

    gcn_results = evaluate(test_true, test_pred)
    gcn_results["confusion_matrix"] = confusion_matrix(test_true, test_pred).tolist()

    torch.save(model.state_dict(), f"{MODELS_DIR}/gcn_model.pt")
    return gcn_results, history, model


def plot_training_curve(history, path):
    fig, ax1 = plt.subplots(figsize=(6, 4))
    ax1.plot(history["epoch"], history["train_loss"], color="tab:red", label="Train Loss")
    ax1.set_xlabel("Epoch")
    ax1.set_ylabel("Loss", color="tab:red")
    ax2 = ax1.twinx()
    ax2.plot(history["epoch"], history["val_acc"], color="tab:blue", label="Val Accuracy")
    ax2.set_ylabel("Validation Accuracy", color="tab:blue")
    fig.suptitle("GCN Training Curve")
    fig.tight_layout()
    fig.savefig(path, dpi=150)
    plt.close(fig)


def plot_comparison(results, path):
    models = list(results.keys())
    accs = [results[m]["accuracy"] * 100 for m in models]
    fig, ax = plt.subplots(figsize=(6, 4))
    bars = ax.bar(models, accs, color=["#888888", "#5b9bd5", "#2e7d32"][:len(models)])
    ax.set_ylabel("Accuracy (%)")
    ax.set_title("Model Comparison: Traditional ML vs GCN")
    ax.set_ylim(0, 100)
    for b, a in zip(bars, accs):
        ax.text(b.get_x() + b.get_width() / 2, a + 1, f"{a:.1f}%", ha="center")
    plt.xticks(rotation=15)
    fig.tight_layout()
    fig.savefig(path, dpi=150)
    plt.close(fig)


def main():
    print("Loading graph data...")
    X, edge_index, y = load_data()
    n = X.shape[0]
    print(f"Nodes={n}, Edges={edge_index.shape[1]}, Feature dim={X.shape[1]}")

    train_mask, val_mask, test_mask = make_masks(n, y)
    print(f"Train={train_mask.sum()}, Val={val_mask.sum()}, Test={test_mask.sum()}")

    print("\n=== Training baseline models (Logistic Regression, Random Forest) ===")
    baseline_results = train_baselines(X, y, train_mask, test_mask)
    for name, r in baseline_results.items():
        print(f"{name}: acc={r['accuracy']:.4f} f1={r['f1']:.4f}")

    print("\n=== Training GCN ===")
    gcn_results, history, model = train_gcn(
        X, edge_index, y, train_mask, val_mask, test_mask,
        hidden=64, epochs=100, lr=0.01, dropout=0.5, svd_dim=None)
    print(f"GCN: acc={gcn_results['accuracy']:.4f} f1={gcn_results['f1']:.4f}")

    all_results = {**baseline_results, "GCN (Ours)": gcn_results}

    # Save metrics
    with open(f"{RESULTS_DIR}/metrics.json", "w") as f:
        json.dump(all_results, f, indent=2)

    # Save plots
    plot_confusion(np.array(gcn_results["confusion_matrix"]),
                    "GCN Confusion Matrix", f"{RESULTS_DIR}/gcn_confusion_matrix.png")
    plot_training_curve(history, f"{RESULTS_DIR}/gcn_training_curve.png")
    plot_comparison(all_results, f"{RESULTS_DIR}/model_comparison.png")

    with open(f"{RESULTS_DIR}/training_history.json", "w") as f:
        json.dump(history, f)

    print("\n=== FINAL RESULTS ===")
    for name, r in all_results.items():
        print(f"{name:22s} | acc={r['accuracy']*100:5.2f}% | prec={r['precision']*100:5.2f}% "
              f"| rec={r['recall']*100:5.2f}% | f1={r['f1']*100:5.2f}%")

    print("\nSaved: results/metrics.json, results/*.png, models/gcn_model.pt")


if __name__ == "__main__":
    main()
