"""
Extractors: turn any supported input into plain text for the model.

Core (always available):   txt, md, pdf, docx, csv, URL
Optional (extra install):  image OCR, video frame OCR, speech-to-text

Optional features raise MissingDependency with the exact pip command, so the
app can show a clear message instead of crashing.
"""
import io
import os
import re
import tempfile

import pandas as pd


class MissingDependency(Exception):
    """Raised when an optional library is not installed."""

    def __init__(self, feature: str, pip_cmd: str):
        super().__init__(f"{feature} needs an extra library. Run: {pip_cmd}")
        self.feature = feature
        self.pip_cmd = pip_cmd


# ---------------------------------------------------------------- helpers
def _squash(text: str) -> str:
    return re.sub(r"[ \t]+", " ", re.sub(r"\n{3,}", "\n\n", text)).strip()


def optional_status() -> dict:
    """Which optional features are installed (shown in the sidebar)."""
    status = {}
    try:
        _get_ocr()
        status["Image and video text (OCR)"] = True
    except Exception:
        status["Image and video text (OCR)"] = False
    try:
        import faster_whisper  # noqa: F401
        status["Speech to text (audio and video)"] = True
    except Exception:
        status["Speech to text (audio and video)"] = False
    return status


# ------------------------------------------------------------------ files
def extract_from_file(name: str, data: bytes) -> str:
    ext = os.path.splitext(name)[1].lower()
    if ext in (".txt", ".md", ".text"):
        return _squash(_decode(data))
    if ext == ".pdf":
        return _squash(_pdf_text(data))
    if ext == ".docx":
        return _squash(_docx_text(data))
    if ext in (".html", ".htm"):
        return _squash(_html_text(_decode(data)))
    raise ValueError(f"Unsupported file type: {ext or 'unknown'}")


def _decode(data: bytes) -> str:
    for enc in ("utf-8", "utf-16", "cp1252", "latin-1"):
        try:
            return data.decode(enc)
        except UnicodeDecodeError:
            continue
    return data.decode("utf-8", errors="ignore")


def _pdf_text(data: bytes) -> str:
    from pypdf import PdfReader
    reader = PdfReader(io.BytesIO(data))
    pages = [(p.extract_text() or "") for p in reader.pages]
    text = "\n".join(pages).strip()
    if not text:
        raise ValueError("No selectable text found in this PDF. "
                         "If it is a scan, upload it as an image instead.")
    return text


def _docx_text(data: bytes) -> str:
    from docx import Document
    doc = Document(io.BytesIO(data))
    parts = [p.text for p in doc.paragraphs if p.text.strip()]
    for table in doc.tables:
        for row in table.rows:
            parts.append(" ".join(c.text for c in row.cells))
    return "\n".join(parts)


def _html_text(html: str) -> str:
    from bs4 import BeautifulSoup
    soup = BeautifulSoup(html, "html.parser")
    for tag in soup(["script", "style", "nav", "footer", "header", "aside"]):
        tag.decompose()
    paras = [p.get_text(" ", strip=True) for p in soup.find_all("p")]
    paras = [p for p in paras if len(p.split()) >= 5]
    return "\n".join(paras) if paras else soup.get_text(" ", strip=True)


# ------------------------------------------------------------------- URL
def extract_from_url(url: str) -> str:
    import requests
    if not re.match(r"^https?://", url.strip(), re.I):
        raise ValueError("Enter a full link that starts with http:// or https://")
    headers = {"User-Agent": "Mozilla/5.0 (FakeNewsDetector student project)"}
    resp = requests.get(url.strip(), headers=headers, timeout=15)
    resp.raise_for_status()
    text = _squash(_html_text(resp.text))
    if len(text.split()) < 20:
        raise ValueError("Could not find article text on that page. "
                         "Copy the article text and use the Text tab instead.")
    return text


# ------------------------------------------------------------------- CSV
def read_csv_rows(data: bytes) -> pd.DataFrame:
    for enc in ("utf-8", "cp1252", "latin-1"):
        try:
            return pd.read_csv(io.BytesIO(data), encoding=enc)
        except UnicodeDecodeError:
            continue
        except pd.errors.EmptyDataError:
            raise ValueError("The CSV file is empty.")
    raise ValueError("Could not read this CSV file.")


def guess_text_column(df: pd.DataFrame) -> str:
    preferred = ["text", "content", "article", "body", "news", "statement", "title"]
    lower = {c.lower(): c for c in df.columns}
    for p in preferred:
        if p in lower:
            return lower[p]
    obj_cols = [c for c in df.columns if df[c].dtype == object]
    if obj_cols:
        return max(obj_cols, key=lambda c: df[c].astype(str).str.len().mean())
    return df.columns[0]


# -------------------------------------------------------------------- OCR
_OCR = None


def _get_ocr():
    global _OCR
    if _OCR is not None:
        return _OCR
    try:
        from rapidocr_onnxruntime import RapidOCR
        _OCR = RapidOCR()
    except ImportError:
        try:
            from rapidocr import RapidOCR
            _OCR = RapidOCR()
        except ImportError:
            raise MissingDependency("Reading text from images and video",
                                    "python -m pip install rapidocr-onnxruntime")
    return _OCR


def _ocr_array(img_array) -> list:
    """Return the list of text lines found in one image (numpy array)."""
    ocr = _get_ocr()
    out = ocr(img_array)
    # rapidocr_onnxruntime -> (result, elapsed); result = [[box, text, score], ...]
    if isinstance(out, tuple):
        result = out[0] or []
        return [item[1] for item in result]
    # newer rapidocr -> object with .txts
    txts = getattr(out, "txts", None)
    return list(txts) if txts else []


def extract_from_image(data: bytes) -> str:
    import numpy as np
    from PIL import Image
    img = Image.open(io.BytesIO(data)).convert("RGB")
    if max(img.size) > 2400:
        img.thumbnail((2400, 2400))
    lines = _ocr_array(np.array(img))
    text = " ".join(l.strip() for l in lines if l.strip())
    if not text:
        raise ValueError("No readable text found in this image.")
    return text


# ------------------------------------------------------------------ video
VIDEO_EXT = (".mp4", ".mov", ".avi", ".mkv", ".webm", ".m4v")
AUDIO_EXT = (".mp3", ".wav", ".m4a", ".ogg", ".flac")


def extract_from_video_frames(data: bytes, suffix: str = ".mp4",
                              every_seconds: float = 2.0,
                              max_frames: int = 40, progress=None) -> str:
    """Read on-screen text (headlines, captions) from sampled video frames."""
    try:
        import cv2
    except ImportError:
        raise MissingDependency("Reading text from video",
                                "python -m pip install rapidocr-onnxruntime")
    _get_ocr()

    tmp = tempfile.NamedTemporaryFile(delete=False, suffix=suffix)
    try:
        tmp.write(data)
        tmp.close()
        cap = cv2.VideoCapture(tmp.name)
        if not cap.isOpened():
            raise ValueError("Could not open this video file.")
        fps = cap.get(cv2.CAP_PROP_FPS) or 25.0
        total = int(cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0)
        step = max(1, int(round(fps * every_seconds)))
        positions = list(range(0, total if total > 0 else step * max_frames, step))
        positions = positions[:max_frames]

        seen, lines = set(), []
        for n, pos in enumerate(positions):
            cap.set(cv2.CAP_PROP_POS_FRAMES, pos)
            ok, frame = cap.read()
            if not ok:
                break
            rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            for line in _ocr_array(rgb):
                key = re.sub(r"\W+", "", line.lower())
                if key and key not in seen:
                    seen.add(key)
                    lines.append(line.strip())
            if progress:
                progress((n + 1) / len(positions))
        cap.release()
    finally:
        try:
            os.remove(tmp.name)
        except OSError:
            pass

    text = " ".join(lines)
    if not text:
        raise ValueError("No on-screen text found in the video frames.")
    return text


def transcribe_media(data: bytes, suffix: str = ".mp4", model_size: str = "tiny") -> str:
    """Speech to text for audio or video (optional, uses faster-whisper)."""
    try:
        from faster_whisper import WhisperModel
    except ImportError:
        raise MissingDependency("Speech to text",
                                "python -m pip install faster-whisper")
    tmp = tempfile.NamedTemporaryFile(delete=False, suffix=suffix)
    try:
        tmp.write(data)
        tmp.close()
        model = WhisperModel(model_size, device="cpu", compute_type="int8")
        segments, _ = model.transcribe(tmp.name)
        text = " ".join(s.text.strip() for s in segments)
    finally:
        try:
            os.remove(tmp.name)
        except OSError:
            pass
    if not text.strip():
        raise ValueError("No speech was detected in this file.")
    return text.strip()
