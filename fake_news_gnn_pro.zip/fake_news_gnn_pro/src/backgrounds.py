"""
Backgrounds: built-in presets (generated once) and helpers to turn any image
into a CSS background for the Streamlit app.
"""
import base64
import io
import os

import numpy as np
from PIL import Image, ImageDraw, ImageFilter

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BG_DIR = os.path.join(BASE, "assets", "backgrounds")
W, H = 1600, 900

PRESETS = {
    "Network night": "network_night.jpg",
    "Deep teal": "deep_teal.jpg",
    "Violet dusk": "violet_dusk.jpg",
}


def _gradient(top, bottom):
    t = np.linspace(0, 1, H)[:, None, None]
    top, bottom = np.array(top)[None, None, :], np.array(bottom)[None, None, :]
    col = (top * (1 - t) + bottom * t).repeat(W, axis=1)
    return Image.fromarray(col.astype("uint8"), "RGB")


def _network(img, node_rgb, line_rgb, seed, n=75, reach=230):
    rng = np.random.default_rng(seed)
    pts = np.column_stack([rng.uniform(0, W, n), rng.uniform(0, H, n)])
    glow = Image.new("RGB", (W, H), (0, 0, 0))
    lines = Image.new("RGB", (W, H), (0, 0, 0))
    gd, ld = ImageDraw.Draw(glow), ImageDraw.Draw(lines)
    for i in range(n):
        for j in range(i + 1, n):
            d = np.hypot(*(pts[i] - pts[j]))
            if d < reach:
                k = 1 - d / reach
                col = tuple(int(c * k * 0.9) for c in line_rgb)
                ld.line([tuple(pts[i]), tuple(pts[j])], fill=col, width=2)
    for x, y in pts:
        r = rng.uniform(3, 7)
        gd.ellipse([x - r, y - r, x + r, y + r], fill=node_rgb)
    glow_blur = glow.filter(ImageFilter.GaussianBlur(9))
    out = np.clip(np.asarray(img, dtype=int) + np.asarray(lines, dtype=int)
                  + np.asarray(glow_blur, dtype=int) + np.asarray(glow, dtype=int) // 2, 0, 255)
    return Image.fromarray(out.astype("uint8"), "RGB")


def _bokeh(img, rgb, seed, n=26):
    rng = np.random.default_rng(seed)
    layer = Image.new("RGB", (W, H), (0, 0, 0))
    d = ImageDraw.Draw(layer)
    for _ in range(n):
        x, y, r = rng.uniform(0, W), rng.uniform(0, H), rng.uniform(40, 150)
        k = rng.uniform(0.15, 0.4)
        d.ellipse([x - r, y - r, x + r, y + r], fill=tuple(int(c * k) for c in rgb))
    layer = layer.filter(ImageFilter.GaussianBlur(28))
    out = np.clip(np.asarray(img, dtype=int) + np.asarray(layer, dtype=int), 0, 255)
    return Image.fromarray(out.astype("uint8"), "RGB")


def make_preset(name: str) -> Image.Image:
    if name == "Deep teal":
        img = _gradient((6, 22, 30), (8, 52, 62))
        return _bokeh(img, (60, 190, 200), seed=11)
    if name == "Violet dusk":
        img = _gradient((20, 10, 40), (52, 24, 76))
        return _network(img, (220, 130, 255), (150, 90, 210), seed=5)
    img = _gradient((8, 12, 28), (14, 26, 56))
    return _network(img, (130, 200, 255), (70, 140, 220), seed=3)


def ensure_presets():
    os.makedirs(BG_DIR, exist_ok=True)
    for name, fname in PRESETS.items():
        path = os.path.join(BG_DIR, fname)
        if not os.path.exists(path):
            make_preset(name).save(path, "JPEG", quality=82)


def preset_bytes(name: str) -> bytes:
    ensure_presets()
    with open(os.path.join(BG_DIR, PRESETS[name]), "rb") as f:
        return f.read()


def to_css_data_uri(image_bytes: bytes, max_width: int = 1600) -> str:
    """Resize and compress any uploaded image so the page stays light."""
    img = Image.open(io.BytesIO(image_bytes)).convert("RGB")
    if img.width > max_width:
        img = img.resize((max_width, int(img.height * max_width / img.width)))
    buf = io.BytesIO()
    img.save(buf, "JPEG", quality=82)
    return "data:image/jpeg;base64," + base64.b64encode(buf.getvalue()).decode()


def page_css(data_uri: str | None, panel_opacity: float = 0.78) -> str:
    bg = (f"background-image: url('{data_uri}'); background-size: cover; "
          f"background-position: center; background-attachment: fixed;"
          if data_uri else "")
    return f"""
<style>
.stApp {{ {bg} }}
[data-testid="stHeader"] {{ background: transparent; }}
.block-container {{
    background: rgba(9, 13, 26, {panel_opacity});
    border: 1px solid rgba(160, 190, 255, 0.14);
    border-radius: 16px;
    padding: 2rem 2.4rem 2.4rem 2.4rem;
    margin-top: 1rem;
    max-width: 1100px;
    backdrop-filter: blur(6px);
}}
[data-testid="stSidebar"] > div:first-child {{ background: rgba(9, 13, 26, 0.94); }}
.verdict {{ border-radius: 14px; padding: 1.1rem 1.4rem; border: 1px solid; margin-bottom: .6rem; }}
.verdict .small {{ font-size: .9rem; opacity: .8; }}
.verdict .big {{ font-size: 1.9rem; font-weight: 700; line-height: 1.25; }}
.verdict .conf {{ font-size: 1rem; opacity: .95; }}
.verdict.fake {{ border-color: #E5484D; background: rgba(229, 72, 77, 0.14); }}
.verdict.fake .big {{ color: #FF7B80; }}
.verdict.real {{ border-color: #30A46C; background: rgba(48, 164, 108, 0.14); }}
.verdict.real .big {{ color: #5FD39A; }}
</style>
"""
