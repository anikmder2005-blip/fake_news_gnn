"""
Step 3 & 4: Convert cleaned text into TF-IDF features, then build an
article-similarity graph.

Nodes  = news articles
Edges  = connect an article to its k most textually-similar articles
         (cosine similarity over TF-IDF vectors)
Labels = FAKE (1) / REAL (0)

This is the "article-centric graph with content similarity" design
recommended for the first working version of the project.
"""
import os
BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
import numpy as np
import pandas as pd
import networkx as nx
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.neighbors import NearestNeighbors
import scipy.sparse as sp
import pickle

RANDOM_STATE = 42


def build_features(df: pd.DataFrame, max_features: int = 5000):
    """TF-IDF vectorize the cleaned text -> node feature matrix."""
    vectorizer = TfidfVectorizer(max_features=max_features, min_df=2)
    X = vectorizer.fit_transform(df["clean_text"])
    return X, vectorizer


def build_knn_graph(X, k: int = 6):
    """Connect each article to its k nearest neighbours by cosine
    similarity over TF-IDF vectors. Returns a symmetric edge list.
    """
    # cosine distance = 1 - cosine similarity; NearestNeighbors handles
    # this efficiently on sparse input without forming a full N x N matrix.
    nn = NearestNeighbors(n_neighbors=k + 1, metric="cosine", algorithm="brute")
    nn.fit(X)
    distances, indices = nn.kneighbors(X)

    edges = set()
    n = X.shape[0]
    for i in range(n):
        for j_idx in range(1, k + 1):  # skip self (index 0)
            j = indices[i, j_idx]
            sim = 1.0 - distances[i, j_idx]
            if sim <= 0:
                continue
            edge = (min(i, j), max(i, j))
            edges.add(edge)

    edge_index = np.array(list(edges)).T  # shape [2, num_edges]
    return edge_index


def build_graph(csv_path: str, max_features: int = 5000, k: int = 6):
    df = pd.read_csv(csv_path)
    df["clean_text"] = df["clean_text"].fillna("")

    print(f"Building TF-IDF features (max_features={max_features})...")
    X, vectorizer = build_features(df, max_features=max_features)
    print("Feature matrix shape:", X.shape)

    print(f"Building k-NN similarity graph (k={k})...")
    edge_index = build_knn_graph(X, k=k)
    print("Number of edges (undirected, unique pairs):", edge_index.shape[1])

    # quick graph stats via networkx
    G = nx.Graph()
    G.add_nodes_from(range(X.shape[0]))
    G.add_edges_from(zip(edge_index[0], edge_index[1]))
    degrees = [d for _, d in G.degree()]
    print(f"Graph nodes={G.number_of_nodes()}, edges={G.number_of_edges()}, "
          f"avg_degree={np.mean(degrees):.2f}, "
          f"isolated_nodes={sum(1 for d in degrees if d == 0)}")

    return X, edge_index, df["y"].values, vectorizer, df


if __name__ == "__main__":
    X, edge_index, y, vectorizer, df = build_graph(
        BASE + "/data/cleaned_news.csv", max_features=5000, k=6
    )

    # Persist everything the training script and the demo app will need
    sp.save_npz(BASE + "/data/node_features.npz", X.tocsr())
    np.save(BASE + "/data/edge_index.npy", edge_index)
    np.save(BASE + "/data/labels.npy", y)
    with open(BASE + "/data/vectorizer.pkl", "wb") as f:
        pickle.dump(vectorizer, f)

    print("Saved: node_features.npz, edge_index.npy, labels.npy, vectorizer.pkl")
