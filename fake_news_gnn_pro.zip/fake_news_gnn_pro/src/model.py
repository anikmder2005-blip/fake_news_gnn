"""
Step 5: The Graph Convolutional Network (GCN) model.

Architecture:
    Input Features -> GCNConv -> ReLU -> Dropout -> GCNConv -> Linear -> 2 classes
"""
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch_geometric.nn import GCNConv


class FakeNewsGCN(nn.Module):
    def __init__(self, in_channels: int, hidden_channels: int = 64,
                 num_classes: int = 2, dropout: float = 0.5):
        super().__init__()
        self.conv1 = GCNConv(in_channels, hidden_channels)
        self.conv2 = GCNConv(hidden_channels, hidden_channels)
        self.classifier = nn.Linear(hidden_channels, num_classes)
        self.dropout = dropout

    def forward(self, x, edge_index):
        h = self.conv1(x, edge_index)
        h = F.relu(h)
        h = F.dropout(h, p=self.dropout, training=self.training)
        h = self.conv2(h, edge_index)
        h = F.relu(h)
        out = self.classifier(h)
        return out
