"""
Predictor: loads the trained GCN and scores any piece of text.

A new article is added to the existing article graph as one extra node,
linked to its k most similar known articles (the same rule used to build
the training graph). The GCN then runs once over the updated graph.
"""
import os
import pickle
import numpy as np
import pandas as pd
import scipy.sparse as sp
import torch
import torch.nn.functional as F
from sklearn.metrics.pairwise import cosine_similarity

from preprocess import clean_text
from model import FakeNewsGCN

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = os.path.join(BASE, "data")
MODELS_DIR = os.path.join(BASE, "models")


class Predictor:
    def __init__(self, k: int = 6):
        self.k = k
        with open(os.path.join(DATA_DIR, "vectorizer.pkl"), "rb") as f:
            self.vectorizer = pickle.load(f)

        self.X = sp.load_npz(os.path.join(DATA_DIR, "node_features.npz")).tocsr()
        edge_index = np.load(os.path.join(DATA_DIR, "edge_index.npy"))
        self.n_nodes, self.n_features = self.X.shape

        # Same graph the model was trained on: every edge in both directions, once.
        ei = torch.tensor(edge_index, dtype=torch.long)
        self.base_edges = torch.cat([ei, ei.flip(0)], dim=1)
        self.x_base = torch.tensor(self.X.toarray(), dtype=torch.float)

        meta_path = os.path.join(DATA_DIR, "articles_meta.csv")
        self.meta = pd.read_csv(meta_path).fillna("")

        self.model = FakeNewsGCN(in_channels=self.n_features, hidden_channels=64,
                                 num_classes=2, dropout=0.5)
        state = torch.load(os.path.join(MODELS_DIR, "gcn_model.pt"), map_location="cpu")
        self.model.load_state_dict(state)
        self.model.eval()

    def predict(self, text: str) -> dict:
        cleaned = clean_text(text)
        n_words = len(cleaned.split())
        vec = self.vectorizer.transform([cleaned])

        sims = cosine_similarity(vec, self.X).ravel()
        top = np.argsort(sims)[::-1][: self.k]
        top_sims = sims[top]

        new_id = self.n_nodes
        new_edges = torch.tensor(
            [[new_id] * len(top) + top.tolist(), top.tolist() + [new_id] * len(top)],
            dtype=torch.long)
        edges = torch.cat([self.base_edges, new_edges], dim=1)
        x = torch.cat([self.x_base, torch.tensor(vec.toarray(), dtype=torch.float)], dim=0)

        with torch.no_grad():
            logits = self.model(x, edges)[new_id]
            probs = F.softmax(logits, dim=0).numpy()

        label = "FAKE" if probs.argmax() == 1 else "REAL"
        neighbours = [
            {
                "index": int(i),
                "title": str(self.meta.iloc[i]["title"]),
                "label": str(self.meta.iloc[i]["label"]).upper(),
                "similarity": float(s),
            }
            for i, s in zip(top, top_sims)
        ]
        return {
            "label": label,
            "confidence": float(probs.max()),
            "p_real": float(probs[0]),
            "p_fake": float(probs[1]),
            "n_words": n_words,
            "max_similarity": float(top_sims[0]) if len(top_sims) else 0.0,
            "neighbours": neighbours,
        }
